<template>
    <div>Show</div>
    <Link href="/">Main Page</Link>
  </template>
  <script setup>
  import { Link } from '@inertiajs/inertia-vue3'
  </script>
  
  <script>
  import MainLayout from '../../Layouts/MainLayout.vue';
  export default {
    layout: MainLayout
  }
  </script>
  <script>
  import MainLayout from '../../Layouts/MainLayout.vue';
  export default {
    layout: MainLayout
  }
  </script>